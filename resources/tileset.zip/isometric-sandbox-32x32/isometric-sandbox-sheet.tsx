<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="isometric-sandbox-sheet" tilewidth="32" tileheight="32" tilecount="2" columns="2" objectalignment="topleft">
 <grid orientation="isometric" width="32" height="32"/>
 <image source="isometric-sandbox-sheet.png" width="80" height="32"/>
</tileset>
